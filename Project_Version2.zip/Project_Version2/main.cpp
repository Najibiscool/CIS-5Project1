/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: taraf
 *
 * Created on July 20, 2024, 11:32 AM
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>

using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays
const int BLACKJACK = 21;
const int DEALER_STAND = 17;

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    // Initialize Random Seed
    srand(static_cast<unsigned int>(time(0)));
    
    // Declare Variables
    char playAgain;

    // Map Inputs to Outputs -> Process
    do {
        int playerTotal = 0;
        int dealerTotal = 0;
        int dealerShown = 0;
        int dealerHidden = 0;

        // Deal initial cards
        {
            int card = rand() % 13 + 1;
            card = (card > 10) ? 10 : card;
            playerTotal += card;

            card = rand() % 13 + 1;
            card = (card > 10) ? 10 : card;
            playerTotal += card;

            card = rand() % 13 + 1;
            card = (card > 10) ? 10 : card;
            dealerShown = card;

            card = rand() % 13 + 1;
            card = (card > 10) ? 10 : card;
            dealerHidden = card;

            dealerTotal = dealerShown + dealerHidden;
        }

        cout << "Dealer shows a " << dealerShown << endl;

        // Player's turn
        {
            char choice;
            do {
                cout << "Player total: " << playerTotal << ". Do you want to hit (h) or stand (s)? ";
                cin >> choice;
                if (choice == 'h') {
                    int newCard = rand() % 13 + 1;
                    newCard = (newCard > 10) ? 10 : newCard;
                    cout << "You drew a " << newCard << endl;
                    playerTotal += newCard;
                }
            } while (choice == 'h' && playerTotal < BLACKJACK);

            if (playerTotal > BLACKJACK) {
                cout << "Player busts with " << playerTotal << "!" << endl;
            }
        }

        // Dealer's turn
        if (playerTotal <= BLACKJACK) {
            cout << "Dealer's hidden card was " << dealerHidden << endl;
            cout << "Dealer's total is " << dealerTotal << endl;

            while (dealerTotal < DEALER_STAND) {
                int newCard = rand() % 13 + 1;
                newCard = (newCard > 10) ? 10 : newCard;
                cout << "Dealer drew a " << newCard << endl;
                dealerTotal += newCard;
            }

            if (dealerTotal > BLACKJACK) {
                cout << "Dealer busts with " << dealerTotal << "!" << endl;
            }
        }

        // Determine winner
        cout << "Player final total: " << playerTotal << endl;
        cout << "Dealer final total: " << dealerTotal << endl;

        if (playerTotal > BLACKJACK) {
            cout << "Dealer wins!" << endl;
        } else if (dealerTotal > BLACKJACK || playerTotal > dealerTotal) {
            cout << "Player wins!" << endl;
        } else if (playerTotal < dealerTotal) {
            cout << "Dealer wins!" << endl;
        } else {
            cout << "It's a tie!" << endl;
        }

        cout << "Do you want to play another round? (y/n): ";
        cin >> playAgain;

    } while (playAgain == 'y');

    // Exit the Program - Cleanup
    return 0;
}




