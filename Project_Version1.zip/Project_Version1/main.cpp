/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: taraf
 *
 * Created on July 19, 2024, 3:12 PM
 */

//System Libraries
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>

using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays
const int BLACKJACK = 21;
const int DEALER_STAND = 17;

//Function Prototypes
int getCardValue();
void dealInitialCards(int &playerTotal, int &dealerTotal);
void playerTurn(int &playerTotal);

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    int playerTotal = 0;
    int dealerTotal = 0;

    //Initialize Variables
    srand(static_cast<unsigned int>(time(0)));
    dealInitialCards(playerTotal, dealerTotal);

    //Map Inputs to Outputs -> Process
    playerTurn(playerTotal);

    //Display Inputs/Outputs
    cout << "Player final total: " << playerTotal << endl;
    cout << "Dealer total: " << dealerTotal << endl;

    //Exit the Program - Cleanup
    return 0;
}

//Function Definitions
int getCardValue() {
    int card = rand() % 13 + 1;
    if (card > 10) return 10; // Face cards
    return card; // 1-10
}

void dealInitialCards(int &playerTotal, int &dealerTotal) {
    playerTotal = getCardValue() + getCardValue();
    dealerTotal = getCardValue() + getCardValue();
}

void playerTurn(int &playerTotal) {
    char choice;
    do {
        cout << "Player total: " << playerTotal << ". Do you want to hit (h) or stand (s)? ";
        cin >> choice;
        if (choice == 'h') {
            int newCard = getCardValue();
            cout << "You drew a " << newCard << endl;
            playerTotal += newCard;
        }
    } while (choice == 'h' && playerTotal < BLACKJACK);

    if (playerTotal > BLACKJACK) {
        cout << "Player busts with " << playerTotal << "!" << endl;
    }
}




