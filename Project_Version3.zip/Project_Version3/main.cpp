/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: taraf
 *
 * Created on July 21, 2024, 11:13 AM
 */

// System Libraries
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>

using namespace std;

// Named Constants
#define BLACKJACK 21
#define DEALER_STAND 17

int main(int argc, char** argv) {
    // Initialize Random Seed
    srand(static_cast<unsigned int>(time(0)));
    
    // Declare Variables
    char playAgain;
    int rounds;

    do {
        cout << "How many rounds do you want to play? ";
        cin >> rounds;

        for (int round = 1; round <= rounds; ++round) {
            cout << "\nROUND\n";

            int playerTotal = 0;
            int dealerTotal = 0;
            int dealerShown = 0;
            int dealerHidden = 0;
            string playerCards = "";
            string dealerCardsShown = "";
            string dealerCardsHidden = "";

            // Deal initial cards
            {
                string cardStr;
                int cardValue;
                int card;
                
                card = rand() % 13 + 1;
                cardValue = (card > 10) ? 10 : card;
                cardStr = (card == 1) ? "ACE" : (card == 11) ? "JACK" : (card == 12) ? "QUEEN" : (card == 13) ? "KING" : to_string(card);
                playerCards += cardStr + " ";
                playerTotal += cardValue;

                card = rand() % 13 + 1;
                cardValue = (card > 10) ? 10 : card;
                cardStr = (card == 1) ? "ACE" : (card == 11) ? "JACK" : (card == 12) ? "QUEEN" : (card == 13) ? "KING" : to_string(card);
                playerCards += cardStr + " ";
                playerTotal += cardValue;

                card = rand() % 13 + 1;
                cardValue = (card > 10) ? 10 : card;
                cardStr = (card == 1) ? "ACE" : (card == 11) ? "JACK" : (card == 12) ? "QUEEN" : (card == 13) ? "KING" : to_string(card);
                dealerCardsShown += cardStr + " ";
                dealerShown = cardValue;

                card = rand() % 13 + 1;
                cardValue = (card > 10) ? 10 : card;
                cardStr = (card == 1) ? "ACE" : (card == 11) ? "JACK" : (card == 12) ? "QUEEN" : (card == 13) ? "KING" : to_string(card);
                dealerCardsHidden += cardStr + " ";
                dealerHidden = cardValue;

                dealerTotal = dealerShown + dealerHidden;
            }

            cout << "Dealer shows a " << dealerCardsShown << endl;

            // Player's turn
            {
                char choice;
                do {
                    cout << "Player cards: " << playerCards << endl;
                    cout << "Player total: " << playerTotal << ". Do you want to hit (h) or stand (s)? ";
                    cin >> choice;
                    if (choice == 'h') {
                        string cardStr;
                        int cardValue;
                        int card;

                        card = rand() % 13 + 1;
                        cardValue = (card > 10) ? 10 : card;
                        cardStr = (card == 1) ? "ACE" : (card == 11) ? "JACK" : (card == 12) ? "QUEEN" : (card == 13) ? "KING" : to_string(card);
                        string cardDisplay = cardStr;
                        cout << "You drew a " << cardDisplay << endl;
                        playerCards += cardDisplay + " ";
                        playerTotal += cardValue;
                    }
                } while (choice == 'h' && playerTotal < BLACKJACK);

                if (playerTotal > BLACKJACK) {
                    cout << "Player busts with " << playerTotal << "!" << endl;
                }
            }

            // Dealer's turn
            if (playerTotal <= BLACKJACK) {
                cout << "Dealer's hidden card was " << dealerCardsHidden << endl;
                dealerCardsShown += dealerCardsHidden;
                cout << "Dealer's total is " << dealerTotal << endl;

                while (dealerTotal < DEALER_STAND) {
                    string cardStr;
                    int cardValue;
                    int card;

                    card = rand() % 13 + 1;
                    cardValue = (card > 10) ? 10 : card;
                    cardStr = (card == 1) ? "ACE" : (card == 11) ? "JACK" : (card == 12) ? "QUEEN" : (card == 13) ? "KING" : to_string(card);
                    string cardDisplay = cardStr;
                    cout << "Dealer drew a " << cardDisplay << endl;
                    dealerCardsShown += cardDisplay + " ";
                    dealerTotal += cardValue;
                }

                if (dealerTotal > BLACKJACK) {
                    cout << "Dealer busts with " << dealerTotal << "!" << endl;
                }
            }

            // Determine winner
            cout << "Player cards: " << playerCards;
            cout << " Player final total: " << playerTotal << endl;

            cout << "Dealer cards: " << dealerCardsShown;
            cout << " Dealer final total: " << dealerTotal << endl;

            if (playerTotal > BLACKJACK) {
                cout << "Dealer wins!" << endl;
            } else if (dealerTotal > BLACKJACK || playerTotal > dealerTotal) {
                cout << "Player wins!" << endl;
            } else if (playerTotal < dealerTotal) {
                cout << "Dealer wins!" << endl;
            } else {
                cout << "It's a tie!" << endl;
            }
        }

        cout << "Do you want to keep playing? (y/n): ";
        cin >> playAgain;

    } while (playAgain == 'y');

    // Exit the Program - Cleanup
    return 0;
}





